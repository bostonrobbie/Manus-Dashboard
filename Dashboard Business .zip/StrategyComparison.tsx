    // Merge data by date
    const dateMap = new Map();
    
    if (strategy1Data.data) {
      strategy1Data.data.forEach((point: any) => {
        const date = new Date(point.date).toISOString().split('T')[0];
        if (!dateMap.has(date)) dateMap.set(date, { date });
        dateMap.get(date)[strategy1?.name || 'Strategy 1'] = parseFloat(point.equity);
      });
    }
    
    if (strategy2Data.data) {
      strategy2Data.data.forEach((point: any) => {
        const date = new Date(point.date).toISOString().split('T')[0];
        if (!dateMap.has(date)) dateMap.set(date, { date });
        dateMap.get(date)[strategy2?.name || 'Strategy 2'] = parseFloat(point.equity);
      });
    }
    
    if (strategy3Data.data) {
      strategy3Data.data.forEach((point: any) => {
        const date = new Date(point.date).toISOString().split('T')[0];
        if (!dateMap.has(date)) dateMap.set(date, { date });
        dateMap.get(date)[strategy3?.name || 'Strategy 3'] = parseFloat(point.equity);
      });
    }

    return Array.from(dateMap.values()).sort((a, b) => a.date.localeCompare(b.date));
  }, [selectedStrategies, strategy1Data.data, strategy2Data.data, strategy3Data.data, strategies]);

  const selectedStrategyObjects = strategies.filter(s => selectedStrategies.includes(s.id));

  const colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          Strategy Comparison
        </h1>
        <p className="text-slate-400 mt-1 text-sm md:text-base">Compare performance across multiple trading strategies</p>
      </div>

      {/* Strategy Selection */}
      <div className="glass-card p-6 mb-6">
        <h2 className="text-lg font-semibold text-white mb-4">Select Strategies to Compare (up to 3)</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {strategies.map((strategy, idx) => (
            <button
              key={strategy.id}
              onClick={() => handleStrategyToggle(strategy.id)}
              className={`p-3 rounded-lg border-2 transition-all ${
                selectedStrategies.includes(strategy.id)
                  ? `border-${colors[selectedStrategies.indexOf(strategy.id)]} bg-${colors[selectedStrategies.indexOf(strategy.id)]}/10`
                  : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
              }`}
              disabled={!selectedStrategies.includes(strategy.id) && selectedStrategies.length >= 3}
            >
              <div className="text-sm font-medium text-white">{strategy.name}</div>
              <div className="text-xs text-slate-400 mt-1">{strategy.type}</div>
            </button>
          ))}
        </div>
      </div>

      {selectedStrategies.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <BarChart3 className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400 text-lg">Select strategies above to begin comparison</p>
        </div>
      ) : (
        <>
          {/* Comparison Metrics Table */}
          <div className="glass-card p-6 mb-6 overflow-x-auto">
            <h2 className="text-lg font-semibold text-white mb-4">Performance Metrics</h2>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-3 px-4 text-slate-400 font-medium">Metric</th>
                  {selectedStrategyObjects.map((strategy, idx) => (
                    <th key={strategy.id} className="text-right py-3 px-4 text-slate-400 font-medium">
                      {strategy.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="text-white">
                <tr className="border-b border-slate-800">
                  <td className="py-3 px-4">Total Return</td>
                  {selectedStrategyObjects.map(strategy => (
                    <td key={strategy.id} className="text-right py-3 px-4 font-mono">
                      ${strategy.totalPnL?.toLocaleString() || '0'}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="py-3 px-4">Win Rate</td>
                  {selectedStrategyObjects.map(strategy => (
                    <td key={strategy.id} className="text-right py-3 px-4 font-mono">
                      {strategy.winRate?.toFixed(2)}%
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="py-3 px-4">Sharpe Ratio</td>
                  {selectedStrategyObjects.map(strategy => (
                    <td key={strategy.id} className="text-right py-3 px-4 font-mono">
                      {strategy.sharpeRatio?.toFixed(2) || 'N/A'}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="py-3 px-4">Max Drawdown</td>
                  {selectedStrategyObjects.map(strategy => (
                  <td key={strategy.id} className="text-right py-3 px-4 font-mono text-red-400">
                    N/A
                  </td>
                  ))}
                </tr>
                <tr>
                  <td className="py-3 px-4">Total Trades</td>
                  {selectedStrategyObjects.map(strategy => (
                    <td key={strategy.id} className="text-right py-3 px-4 font-mono">
                      {strategy.totalTrades || 0}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          {/* Equity Curve Comparison */}
          <div className="glass-card p-6 mb-6">
            <h2 className="text-lg font-semibold text-white mb-4">Equity Curve Comparison</h2>
            {combinedEquityCurve.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={combinedEquityCurve}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#94a3b8"
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis stroke="#94a3b8" tickFormatter={(value) => `$${value.toLocaleString()}`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#e2e8f0' }}
                    formatter={(value: any) => [`$${parseFloat(value).toLocaleString()}`, '']}
                  />