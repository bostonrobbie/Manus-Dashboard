import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowDown, ArrowUp, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: number;
  format?: 'number' | 'currency' | 'percent';
  icon?: React.ReactNode;
  loading?: boolean;
  className?: string;
}

export function MetricCard({
  title,
  value,
  change,
  format = 'number',
  icon,
  loading = false,
  className,
}: MetricCardProps) {
  const formatValue = (val: string | number) => {
    if (typeof val === 'string') return val;
    
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('en-US', {
          style: 'currency',
          currency: 'USD',
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
        }).format(val);
      case 'percent':
        return `${val >= 0 ? '+' : ''}${val.toFixed(2)}%`;
      default:
        return val.toLocaleString();
    }
  };

  const getChangeColor = (val: number) => {
    if (val > 0) return 'text-success';
    if (val < 0) return 'text-danger';
    return 'text-muted-foreground';
  };

  const getChangeIcon = (val: number) => {
    if (val > 0) return <ArrowUp className="h-4 w-4" />;
    if (val < 0) return <ArrowDown className="h-4 w-4" />;
    return <Minus className="h-4 w-4" />;
  };

  if (loading) {
    return (
      <Card className={cn("glass", className)}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            {title}
          </CardTitle>
          {icon && <div className="text-muted-foreground">{icon}</div>}
        </CardHeader>
        <CardContent>
          <div className="h-8 w-32 animate-pulse bg-muted rounded" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("glass transition-all hover:border-primary/50", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        {icon && <div className="text-muted-foreground">{icon}</div>}
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold tracking-tight">
          {formatValue(value)}
        </div>
        {change !== undefined && (
          <div className={cn("flex items-center gap-1 text-sm mt-2", getChangeColor(change))}>
            {getChangeIcon(change)}
            <span>{Math.abs(change).toFixed(2)}%</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
