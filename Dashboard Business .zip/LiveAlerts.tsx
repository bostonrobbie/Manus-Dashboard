import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, CheckCircle, XCircle, AlertCircle, Clock, Code, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";

export default function LiveAlerts() {
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [selectedLog, setSelectedLog] = useState<any>(null);

  // Fetch webhook logs
  const { data: webhookLogs = [], refetch } = trpc.webhooks.logs.useQuery({
    limit: 100
  });

  // Auto-refresh every 3 seconds
  useEffect(() => {
    if (!autoRefresh) return;
    
    const interval = setInterval(() => {
      refetch();
    }, 3000);

    return () => clearInterval(interval);
  }, [autoRefresh, refetch]);

  // Calculate stats (based on statusCode)
  const successCount = webhookLogs.filter(log => log.statusCode >= 200 && log.statusCode < 300).length;
  const failureCount = webhookLogs.filter(log => log.statusCode >= 400).length;
  const pendingCount = 0; // No pending status in current schema
  const successRate = webhookLogs.length > 0 ? (successCount / webhookLogs.length) * 100 : 0;

  // Get recent logs (last 24 hours)
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const recentLogs = webhookLogs.filter(log => new Date(log.createdAt) > oneDayAgo);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'failure':
        return <XCircle className="w-4 h-4 text-red-400" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      default:
        return <AlertCircle className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'failure':
        return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      default:
        return 'bg-slate-500/20 text-slate-400 border-slate-500/50';
    }
  };

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent flex items-center gap-2">
            <Bell className="w-6 h-6 md:w-8 md:h-8 text-purple-400" />
            Live Alerts & Webhook Logs
          </h1>
          <p className="text-slate-400 mt-1 text-sm md:text-base">Monitor TradingView webhooks in real-time</p>
        </div>

        <div className="flex flex-wrap gap-2 md:gap-4 items-center">
          <Button
            variant={autoRefresh ? "default" : "outline"}
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={autoRefresh ? "bg-green-500 hover:bg-green-600" : ""}
          >
            {autoRefresh ? (
              <>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse mr-2" />
                Auto-Refresh
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Paused
              </>
            )}
          </Button>

          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Now
          </Button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Total Webhooks</span>
              <Bell className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {webhookLogs.length}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Successful</span>
              <CheckCircle className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-green-400">
              {successCount}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Failed</span>
              <XCircle className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl font-bold text-red-400">
              {failureCount}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Pending</span>
              <Clock className="w-4 h-4 text-yellow-400" />
            </div>
            <div className="text-2xl font-bold text-yellow-400">
              {pendingCount}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Success Rate</span>
              <CheckCircle className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">
              {successRate.toFixed(1)}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Webhook Log List */}
        <div className="lg:col-span-2">
          <Card className="glass-card border-slate-700/50">
            <CardHeader>
              <CardTitle className="text-slate-100 flex items-center justify-between">
                <span>Recent Webhooks</span>
                {autoRefresh && (
                  <span className="text-xs text-green-400 flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    Live
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {webhookLogs.length > 0 ? (
                <div className="space-y-2 max-h-[600px] overflow-y-auto">
                  {webhookLogs
                    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                    .map((log) => (
                      <div
                        key={log.id}
                        onClick={() => setSelectedLog(log)}
                        className={`p-4 rounded-lg border cursor-pointer transition-all ${
                          selectedLog?.id === log.id
                            ? 'bg-slate-700/50 border-cyan-500'
                            : 'bg-slate-800/30 border-slate-700 hover:bg-slate-700/30'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(log.statusCode >= 200 && log.statusCode < 300 ? 'success' : 'failure')}
                            <span className="font-medium text-slate-100">{log.endpoint}</span>
                            <Badge variant="outline" className={getStatusColor(log.statusCode >= 200 && log.statusCode < 300 ? 'success' : 'failure')}>
                              {log.statusCode}
                            </Badge>
                          </div>
                          <span className="text-xs text-slate-400">
                            {new Date(log.createdAt).toLocaleString()}
                          </span>
                        </div>
                        
                        {log.error && (
                          <div className="text-sm text-red-400 mt-2 p-2 bg-red-500/10 rounded">
                            {log.error}
                          </div>
                        )}

                        <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                          <span>User ID: {log.userId}</span>
                          {log.processingTime && (
                            <span>
                              Processing time: {log.processingTime}ms
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <Bell className="w-12 h-12 mx-auto mb-4 text-slate-600" />
                  <p className="text-lg">No webhooks received yet</p>
                  <p className="text-sm mt-2">
                    Configure your TradingView alerts to start receiving webhooks
                  </p>
                  <Link href="/tradingview-setup">
                    <Button variant="outline" className="mt-4">
                      View Setup Guide
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Webhook Detail Panel */}
        <div>
          <Card className="glass-card border-slate-700/50 sticky top-6">
            <CardHeader>
              <CardTitle className="text-slate-100 flex items-center gap-2">
                <Code className="w-5 h-5" />
                Webhook Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedLog ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-slate-400 uppercase tracking-wide">Status Code</label>
                    <div className="mt-1">
                      <Badge variant="outline" className={getStatusColor(selectedLog.statusCode >= 200 && selectedLog.statusCode < 300 ? 'success' : 'failure')}>
                        {selectedLog.statusCode}
                      </Badge>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 uppercase tracking-wide">Endpoint</label>
                    <div className="mt-1 text-slate-100 font-medium">{selectedLog.endpoint}</div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 uppercase tracking-wide">Received At</label>
                    <div className="mt-1 text-slate-100">
                      {new Date(selectedLog.createdAt).toLocaleString()}
                    </div>
                  </div>

                  {selectedLog.processingTime && (
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide">Processing Time</label>
                      <div className="mt-1 text-slate-100">
                        {selectedLog.processingTime}ms
                      </div>
                    </div>
                  )}

                  {selectedLog.error && (
                    <div>
                      <label className="text-xs text-slate-400 uppercase tracking-wide">Error Message</label>
                      <div className="mt-1 p-3 bg-red-500/10 border border-red-500/30 rounded text-red-400 text-sm">
                        {selectedLog.error}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-xs text-slate-400 uppercase tracking-wide">Payload</label>
                    <div className="mt-1 p-3 bg-slate-900/50 rounded border border-slate-700 overflow-x-auto">
                      <pre className="text-xs text-slate-300">
                        {JSON.stringify(selectedLog.payload, null, 2)}
                      </pre>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs text-slate-400 uppercase tracking-wide">Response</label>
                    <div className="mt-1 p-3 bg-slate-900/50 rounded border border-slate-700 overflow-x-auto">
                      <pre className="text-xs text-slate-300">
                        {selectedLog.response ? JSON.stringify(selectedLog.response, null, 2) : 'No response data'}
                      </pre>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <Code className="w-12 h-12 mx-auto mb-4 text-slate-600" />
                  <p>Select a webhook to view details</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
