// Version: 2025-11-13 - Production ready
import { useState, useEffect } from "react";
import { MetricCard } from "@/components/MetricCard";
import { trpc } from "@/lib/trpc";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { TrendingUp, TrendingDown, Activity, DollarSign, Target, BarChart3, PieChart, AlertCircle } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import { ContractSizeToggle, useContractSize, scaleByContractSize } from "@/components/ContractSizeToggle";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

export default function DashboardNew() {
  const contractSize = useContractSize();
  const [showCombined, setShowCombined] = useState(true);
  const [showSwing, setShowSwing] = useState(false);
  const [showIntraday, setShowIntraday] = useState(false);
  const [showSPX, setShowSPX] = useState(false);
  
  const { data: overview, isLoading: overviewLoading } = trpc.portfolio.overview.useQuery();
  const { data: equityData, isLoading: equityLoading } = trpc.portfolio.equityCurveWithBenchmark.useQuery({});
  const { data: positions } = trpc.portfolio.positions.useQuery({});

  const isLoading = overviewLoading || equityLoading;

  // Scale all values based on contract size
  const scaledOverview = overview ? {
    ...overview,
    equity: scaleByContractSize(overview.equity, contractSize),
    dailyPnL: scaleByContractSize(overview.dailyPnL || 0, contractSize),
    maxDrawdown: scaleByContractSize(overview.maxDrawdown, contractSize),
    avgWin: scaleByContractSize(overview.avgWin || 0, contractSize),
    avgLoss: scaleByContractSize(overview.avgLoss || 0, contractSize),
  } : undefined;

  // Prepare multi-curve data: Combined, Swing, Intraday, SPX
  // All curves normalized to start at $0 and scaled by contract size
  const multiCurveData = equityData && equityData.dates.length > 0 ? equityData.dates.map((date, i) => {
    const combined = scaleByContractSize(equityData.combined[i], contractSize);
    const swing = equityData.swing ? scaleByContractSize(equityData.swing[i], contractSize) : 0;
    const intraday = equityData.intraday ? scaleByContractSize(equityData.intraday[i], contractSize) : 0;
    const spx = equityData.spx ? equityData.spx[i] : 0;
    
    return {
      date,
      combined,
      swing,
      intraday,
      spx,
    };
  }) : [];
  
  // Backend now returns normalized curves (starting at $0), so just use the data as-is
  const normalizedEquityCurve = multiCurveData;
  
  // Debug: Log sample data points
  useEffect(() => {
    if (normalizedEquityCurve.length > 0) {
      console.log('[DashboardNew] Sample data point 0:', normalizedEquityCurve[0]);
      console.log('[DashboardNew] Sample data point 100:', normalizedEquityCurve[100]);
      console.log('[DashboardNew] Sample data point last:', normalizedEquityCurve[normalizedEquityCurve.length - 1]);
    }
  }, [normalizedEquityCurve.length]);
  
  // For backward compatibility with daily returns calculation
  const equityCurve = normalizedEquityCurve.map(p => ({
    date: p.date,
    equity: p.combined,
  }));
  
  // Calculate daily returns for the bar chart
  const dailyReturnsData = equityCurve.length > 1
    ? equityCurve.slice(1).map((point, i) => {
        const prevEquity = equityCurve[i].equity;
        const dailyReturn = prevEquity > 0 ? ((point.equity - prevEquity) / prevEquity) * 100 : 0;
        return {
          date: point.date,
          dailyReturn,
          dailyPnL: point.equity - prevEquity,
        };
      })
    : [];

  return (
    <DashboardLayout>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Portfolio Overview</h1>
          <p className="text-slate-400 mt-1">Real-time trading performance across all strategies</p>
        </div>
        <ContractSizeToggle />
      </div>

      <main className="container mx-auto px-6 py-8">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total Equity"
            value={scaledOverview?.equity || 0}
            format="currency"
            change={overview?.dailyReturn || 0}
            icon={<DollarSign className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Daily Return"
            value={scaledOverview?.dailyReturn || 0}
            format="percent"
            change={scaledOverview?.dailyReturn || 0}
            icon={overview && overview.dailyReturn >= 0 ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Sharpe Ratio (60d)"
            value={scaledOverview?.sharpeRatio || 0}
            format="number"
            icon={<Activity className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Max Drawdown"
            value={scaledOverview?.maxDrawdown ? -Math.abs(scaledOverview.maxDrawdown) : 0}
            format="currency"
            icon={<AlertCircle className="w-5 h-5" />}
            loading={isLoading}
          />
        </div>

        {/* Secondary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Win Rate"
            value={scaledOverview?.winRate || 0}
            format="percent"
            icon={<Target className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Profit Factor"
            value={scaledOverview?.profitFactor || 0}
            format="number"
            icon={<BarChart3 className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Active Positions"
            value={positions?.length || 0}
            format="number"
            icon={<PieChart className="w-5 h-5" />}
            loading={isLoading}
          />
          <MetricCard
            title="Total Trades"
            value={scaledOverview?.totalTrades || 0}
            format="number"
            icon={<BarChart3 className="w-5 h-5" />}
            loading={isLoading}
          />
        </div>

        {/* Equity Curve Chart with Multi-Curve Toggle */}
        <div className="glass-card p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-white">Equity Curve</h2>
            
            {/* Curve Toggles */}
            <div className="flex gap-6 items-center">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="show-combined" 
                  checked={showCombined} 
                  onCheckedChange={(checked) => setShowCombined(checked === true)}
                  className="border-blue-500 data-[state=checked]:bg-blue-500"
                />
                <Label htmlFor="show-combined" className="text-sm text-slate-300 cursor-pointer">
                  Combined
                </Label>
              </div>
              
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="show-swing" 
                  checked={showSwing} 
                  onCheckedChange={(checked) => setShowSwing(checked === true)}
                  className="border-green-500 data-[state=checked]:bg-green-500"
                />
                <Label htmlFor="show-swing" className="text-sm text-slate-300 cursor-pointer">
                  Swing
                </Label>
              </div>
              
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="show-intraday" 
                  checked={showIntraday} 
                  onCheckedChange={(checked) => setShowIntraday(checked === true)}
                  className="border-cyan-500 data-[state=checked]:bg-cyan-500"
                />
                <Label htmlFor="show-intraday" className="text-sm text-slate-300 cursor-pointer">
                  Intraday
                </Label>
              </div>
              
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="show-spx" 
                  checked={showSPX} 
                  onCheckedChange={(checked) => setShowSPX(checked === true)}
                  className="border-yellow-500 data-[state=checked]:bg-yellow-500"
                />
                <Label htmlFor="show-spx" className="text-sm text-slate-300 cursor-pointer">
                  S&P 500
                </Label>
              </div>
            </div>
          </div>
          
          {normalizedEquityCurve && normalizedEquityCurve.length > 0 ? (
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={normalizedEquityCurve}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="date" 
                  stroke="#94a3b8"
                  tickFormatter={(value) => new Date(value).toLocaleDateString()}
                />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#e2e8f0' }}
                  formatter={(value: number) => `$${value.toFixed(0)}`}
                />
                <Legend />
                
                {showCombined && (
                  <Line 
                    type="monotone" 
                    dataKey="combined" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={false}
                    name="Combined Portfolio"
                  />
                )}
                
                {showSwing && (
                  <Line 
                    type="monotone" 
                    dataKey="swing" 
                    stroke="#22c55e" 
                    strokeWidth={2}
                    dot={false}
                    name="Swing Strategies"
                  />
                )}
                
                {showIntraday && (
                  <Line 
                    type="monotone" 
                    dataKey="intraday" 
                    stroke="#06b6d4" 
                    strokeWidth={2}
                    dot={false}
                    name="Intraday Strategies"
                  />
                )}
                
                {showSPX && (
                  <Line 
                    type="monotone" 
                    dataKey="spx" 
                    stroke="#eab308" 
                    strokeWidth={2}
                    dot={false}
                    name="S&P 500"
                    strokeDasharray="5 5"
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[400px] flex items-center justify-center text-slate-400">
              {isLoading ? "Loading equity data..." : "No equity data available"}
            </div>
          )}
        </div>

        {/* Daily Returns Chart */}
        <div className="glass-card p-6 mb-8">
          <h2 className="text-xl font-semibold text-white mb-6">Daily Returns</h2>
          {dailyReturnsData && dailyReturnsData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dailyReturnsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="date" 
                  stroke="#94a3b8"
                  tickFormatter={(value) => new Date(value).toLocaleDateString()}
                />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Bar 
                  dataKey="dailyReturn" 
                  fill="#3b82f6"
                  name="Daily Return %"
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-slate-400">
              {isLoading ? "Loading returns data..." : "No returns data available"}
            </div>
          )}
        </div>

        {/* Current Positions */}
        {positions && positions.length > 0 && (
          <div className="glass-card p-6">
            <h2 className="text-xl font-semibold text-white mb-6">Current Positions</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left py-3 px-4 text-slate-300 font-medium">Symbol</th>
                    <th className="text-left py-3 px-4 text-slate-300 font-medium">Side</th>
                    <th className="text-right py-3 px-4 text-slate-300 font-medium">Quantity</th>
                    <th className="text-right py-3 px-4 text-slate-300 font-medium">Entry Price</th>
                    <th className="text-right py-3 px-4 text-slate-300 font-medium">Current Price</th>
                    <th className="text-right py-3 px-4 text-slate-300 font-medium">Unrealized P&L</th>
                    <th className="text-right py-3 px-4 text-slate-300 font-medium">Return %</th>
                  </tr>
                </thead>
                <tbody>
                  {positions.map((position) => (
                    <tr key={position.id} className="border-b border-slate-800 hover:bg-slate-800/30">
                      <td className="py-3 px-4 text-white font-medium">{position.symbol}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          position.side === 'long' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {position.side.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right text-slate-300">{position.quantity.toFixed(2)}</td>
                      <td className="py-3 px-4 text-right text-slate-300">${position.entryPrice.toFixed(2)}</td>
                      <td className="py-3 px-4 text-right text-slate-300">${position.currentPrice.toFixed(2)}</td>
                      <td className={`py-3 px-4 text-right font-medium ${
                        position.unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        ${position.unrealizedPnL.toFixed(2)}
                      </td>
                      <td className={`py-3 px-4 text-right font-medium ${
                        position.unrealizedPnLPercent >= 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {position.unrealizedPnLPercent >= 0 ? '+' : ''}{position.unrealizedPnLPercent.toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </DashboardLayout>
  );
}
