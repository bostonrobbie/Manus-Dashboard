import { useEffect, useState } from 'react';
import { trades, type TradesResponse, type TradeStats } from '@/lib/api';

/**
 * Hook to fetch trades list
 */
export function useTrades(params?: {
  symbol?: string;
  side?: 'buy' | 'sell';
  start_date?: string;
  end_date?: string;
  offset?: number;
  limit?: number;
}) {
  const [data, setData] = useState<TradesResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await trades.list(params);
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, [
    params?.symbol,
    params?.side,
    params?.start_date,
    params?.end_date,
    params?.offset,
    params?.limit,
  ]);

  return { data, loading, error, refetch };
}

/**
 * Hook to fetch trade statistics
 */
export function useTradeStats(params?: {
  symbol?: string;
  start_date?: string;
  end_date?: string;
}) {
  const [data, setData] = useState<TradeStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await trades.getStats(params);
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, [params?.symbol, params?.start_date, params?.end_date]);

  return { data, loading, error, refetch };
}
