import { useEffect, useRef, useState } from 'react';
import { createWebSocket, type WebSocketMessage } from '@/lib/api';

export interface UseWebSocketOptions {
  channels?: string[];
  onMessage?: (message: WebSocketMessage) => void;
  autoReconnect?: boolean;
  reconnectInterval?: number;
  maxRetries?: number;
  enabled?: boolean;
}

/**
 * Hook to manage WebSocket connection for real-time updates
 */
export function useWebSocket(options: UseWebSocketOptions = {}) {
  const {
    channels = ['all'],
    onMessage,
    autoReconnect = true,
    reconnectInterval = 3000,
    maxRetries = 5,
    enabled = true,
  } = options;

  const [connected, setConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const retriesRef = useRef(0);

  const connect = () => {
    if (!enabled) {
      return; // WebSocket disabled
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    // Stop retrying after max retries
    if (retriesRef.current >= maxRetries) {
      // Silently give up - backend is not available
      return;
    }

    try {
      const ws = createWebSocket(
        channels,
        (message) => {
          setLastMessage(message);
          onMessage?.(message);
          // Reset retry count on successful message
          retriesRef.current = 0;
        },
        () => {
          // Silently handle error - don't spam console
          setConnected(false);
        },
        (event) => {
          // Silently handle close
          setConnected(false);

          // Auto-reconnect if enabled and not a clean close
          if (autoReconnect && event.code !== 1000) {
            retriesRef.current += 1;
            
            if (retriesRef.current < maxRetries) {
              reconnectTimeoutRef.current = setTimeout(() => {
                connect();
              }, reconnectInterval);
            }
          }
        }
      );

      ws.onopen = () => {
        setConnected(true);
        retriesRef.current = 0; // Reset retry count on successful connection
      };

      wsRef.current = ws;
    } catch (error) {
      // Silently handle error - backend not available
      setConnected(false);
    }
  };

  const disconnect = () => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close(1000, 'Client disconnect');
      wsRef.current = null;
    }

    setConnected(false);
  };

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, [channels.join(',')]); // Reconnect if channels change

  return {
    connected,
    lastMessage,
    connect,
    disconnect,
  };
}
