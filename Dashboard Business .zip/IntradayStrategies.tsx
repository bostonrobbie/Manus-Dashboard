import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Activity, DollarSign, Clock, Zap, Target } from "lucide-react";
import { Link } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { ContractSizeToggle, useContractSize, scaleByContractSize } from "@/components/ContractSizeToggle";

export default function IntradayStrategies() {
  const contractSize = useContractSize();
  const [selectedStrategy, setSelectedStrategy] = useState<number | "all">("all");
  const [liveUpdates, setLiveUpdates] = useState(true);

  // Fetch strategies
  const { data: strategies = [] } = trpc.strategies.list.useQuery();
  
  // Filter for intraday strategies
  const intradayStrategies = strategies.filter(s => s.type === 'intraday');

  // Fetch today's trades
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStr = today.toISOString().split('T')[0];

  const { data: todayTrades = [], refetch: refetchTrades } = trpc.trades.list.useQuery({
    strategyId: selectedStrategy === "all" ? undefined : selectedStrategy,
    startDate: todayStr,
    limit: 100
  });

  const { data: overview, refetch: refetchOverview } = trpc.portfolio.overview.useQuery();

  // Auto-refresh every 5 seconds if live updates enabled
  useEffect(() => {
    if (!liveUpdates) return;
    
    const interval = setInterval(() => {
      refetchTrades();
      refetchOverview();
    }, 5000);

    return () => clearInterval(interval);
  }, [liveUpdates, refetchTrades, refetchOverview]);

  // Calculate today's metrics
  const todayWins = todayTrades.filter(t => t.pnl && t.pnl > 0);
  const todayLosses = todayTrades.filter(t => t.pnl && t.pnl < 0);
  const todayPnL = todayTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  const todayWinRate = todayTrades.length > 0 ? (todayWins.length / todayTrades.length) * 100 : 0;

  // Calculate average trade duration (in minutes)
  const tradesWithDuration = todayTrades.filter(t => t.entryTime && t.exitTime);
  const avgDuration = tradesWithDuration.length > 0
    ? tradesWithDuration.reduce((sum, t) => {
        const duration = new Date(t.exitTime!).getTime() - new Date(t.entryTime).getTime();
        return sum + duration;
      }, 0) / tradesWithDuration.length / (1000 * 60) // Convert to minutes
    : 0;

  // Find largest win/loss today
  const largestWin = todayWins.length > 0 ? Math.max(...todayWins.map(t => t.pnl || 0)) : 0;
  const largestLoss = todayLosses.length > 0 ? Math.min(...todayLosses.map(t => t.pnl || 0)) : 0;

  // Scale metrics by contract size
  const scaledTodayPnL = scaleByContractSize(todayPnL, contractSize);
  const scaledLargestWin = scaleByContractSize(largestWin, contractSize);
  const scaledLargestLoss = scaleByContractSize(largestLoss, contractSize);

  // Prepare intraday PnL chart (cumulative throughout the day) - scaled by contract size
  const intradayPnL = todayTrades
    .sort((a, b) => new Date(a.exitTime || a.entryTime).getTime() - new Date(b.exitTime || b.entryTime).getTime())
    .map((trade, index, arr) => {
      const cumulativePnL = arr.slice(0, index + 1).reduce((sum, t) => sum + (t.pnl || 0), 0);
      return {
        time: new Date(trade.exitTime || trade.entryTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        pnl: scaleByContractSize(cumulativePnL, contractSize),
        trade: `${trade.symbol} ${trade.side}`
      };
    });

  // Prepare trade timeline (individual trades) - scaled by contract size
  const tradeTimeline = todayTrades
    .sort((a, b) => new Date(a.exitTime || a.entryTime).getTime() - new Date(b.exitTime || b.entryTime).getTime())
    .map(trade => ({
      time: new Date(trade.exitTime || trade.entryTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      pnl: scaleByContractSize(trade.pnl || 0, contractSize),
      symbol: trade.symbol,
      side: trade.side
    }));

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent flex items-center gap-2">
            <Zap className="w-8 h-8 text-cyan-400" />
            Intraday Strategies
          </h1>
          <p className="text-slate-400 mt-1">Real-time monitoring and performance tracking</p>
        </div>

        <div className="flex gap-4 items-center">
          <ContractSizeToggle />
          <div className="flex items-center gap-2">
            <Button
              variant={liveUpdates ? "default" : "outline"}
              size="sm"
              onClick={() => setLiveUpdates(!liveUpdates)}
              className={liveUpdates ? "bg-green-500 hover:bg-green-600" : ""}
            >
              {liveUpdates ? (
                <>
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse mr-2" />
                  Live
                </>
              ) : (
                "Paused"
              )}
            </Button>
          </div>

          <Select value={String(selectedStrategy)} onValueChange={(v) => setSelectedStrategy(v === "all" ? "all" : Number(v))}>
            <SelectTrigger className="w-[200px] bg-slate-800/50 border-slate-700">
              <SelectValue placeholder="Select strategy" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Intraday Strategies</SelectItem>
              {intradayStrategies.map(s => (
                <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Today's Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Today's P&L</span>
              <DollarSign className="w-4 h-4 text-cyan-400" />
            </div>
            <div className={`text-2xl font-bold ${scaledTodayPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {scaledTodayPnL >= 0 ? '+' : ''}${scaledTodayPnL.toFixed(2)}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Trades Today</span>
              <Activity className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {todayTrades.length}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Win Rate</span>
              <Target className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {todayWinRate.toFixed(0)}%
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Avg Duration</span>
              <Clock className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {avgDuration > 0 ? `${avgDuration.toFixed(0)}m` : 'N/A'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Wins</span>
              <TrendingUp className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-green-400">
              {todayWins.length}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Losses</span>
              <TrendingDown className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl font-bold text-red-400">
              {todayLosses.length}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Best Trade</span>
              <TrendingUp className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-green-400">
              {scaledLargestWin > 0 ? `$${scaledLargestWin.toFixed(0)}` : '$0'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1: Intraday P&L + Trade Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Intraday P&L Curve */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100 flex items-center justify-between">
              <span>Intraday P&L Curve</span>
              {liveUpdates && (
                <span className="text-xs text-green-400 flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  Live
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {intradayPnL.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={intradayPnL}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="time" 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="pnl" 
                    stroke="#06b6d4" 
                    strokeWidth={3}
                    dot={{ fill: '#06b6d4', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No trades today yet
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trade Timeline */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Trade Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            {tradeTimeline.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={tradeTimeline}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="time" 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                  />
                  <YAxis 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Bar 
                    dataKey="pnl" 
                    radius={[4, 4, 0, 0]}
                  >
                    {tradeTimeline.map((entry, index) => (
                      <rect key={index} fill={entry.pnl >= 0 ? '#10b981' : '#ef4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No trades today yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Live Trade Feed */}
      <Card className="glass-card border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-slate-100 flex items-center justify-between">
            <span>Today's Trades</span>
            {liveUpdates && todayTrades.length > 0 && (
              <span className="text-sm text-slate-400">
                Last updated: {new Date().toLocaleTimeString()}
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {todayTrades.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left p-3 text-slate-400 font-medium">Time</th>
                    <th className="text-left p-3 text-slate-400 font-medium">Symbol</th>
                    <th className="text-left p-3 text-slate-400 font-medium">Side</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Entry</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Exit</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Qty</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Duration</th>
                    <th className="text-right p-3 text-slate-400 font-medium">P&L</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Return</th>
                  </tr>
                </thead>
                <tbody>
                  {todayTrades
                    .sort((a, b) => new Date(b.exitTime || b.entryTime).getTime() - new Date(a.exitTime || a.entryTime).getTime())
                    .map((trade) => {
                      const duration = trade.exitTime && trade.entryTime
                        ? (new Date(trade.exitTime).getTime() - new Date(trade.entryTime).getTime()) / (1000 * 60)
                        : null;
                      
                      return (
                        <tr key={trade.id} className="border-b border-slate-800 hover:bg-slate-800/30">
                          <td className="p-3 text-slate-300">
                            {new Date(trade.exitTime || trade.entryTime).toLocaleTimeString('en-US', { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </td>
                          <td className="p-3 text-slate-100 font-medium">{trade.symbol}</td>
                          <td className="p-3">
                            <span className={`px-2 py-1 rounded text-xs ${
                              trade.side === 'long' || trade.side === 'buy' 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-red-500/20 text-red-400'
                            }`}>
                              {trade.side.toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 text-right text-slate-300">${trade.entryPrice.toFixed(2)}</td>
                          <td className="p-3 text-right text-slate-300">
                            {trade.exitPrice ? `$${trade.exitPrice.toFixed(2)}` : '-'}
                          </td>
                          <td className="p-3 text-right text-slate-300">{trade.quantity}</td>
                          <td className="p-3 text-right text-slate-300">
                            {duration ? `${duration.toFixed(0)}m` : '-'}
                          </td>
                          <td className={`p-3 text-right font-medium ${
                            trade.pnl && trade.pnl > 0 ? 'text-green-400' : trade.pnl && trade.pnl < 0 ? 'text-red-400' : 'text-slate-400'
                          }`}>
                            {trade.pnl ? `${trade.pnl >= 0 ? '+' : ''}$${trade.pnl.toFixed(2)}` : '-'}
                          </td>
                          <td className={`p-3 text-right font-medium ${
                            trade.pnlPercent && trade.pnlPercent > 0 ? 'text-green-400' : trade.pnlPercent && trade.pnlPercent < 0 ? 'text-red-400' : 'text-slate-400'
                          }`}>
                            {trade.pnlPercent ? `${trade.pnlPercent >= 0 ? '+' : ''}${trade.pnlPercent.toFixed(2)}%` : '-'}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <Zap className="w-12 h-12 mx-auto mb-4 text-slate-600" />
              <p className="text-lg">No trades today yet</p>
              <p className="text-sm mt-2">Trades will appear here in real-time as they come in from TradingView</p>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
