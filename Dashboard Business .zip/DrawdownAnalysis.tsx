import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { TrendingDown, AlertTriangle, Clock, Target } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";

type TimeRange = '1M' | '3M' | '6M' | '1Y' | 'ALL';

export default function DrawdownAnalysis() {
  const [selectedStrategy, setSelectedStrategy] = useState<string>("all");
  const [timeRange, setTimeRange] = useState<TimeRange>('ALL');

  // Fetch all strategies
  const { data: strategies = [] } = trpc.strategies.list.useQuery();

  // Fetch equity curve data based on selection
  const { data: equityCurveData, isLoading } = trpc.portfolio.equityCurveWithBenchmark.useQuery({});

  // Calculate drawdown data
  const drawdownData = useMemo(() => {
    if (!equityCurveData) return [];

    const { dates, combined, swing, intraday } = equityCurveData;
    
    // Select the appropriate equity series
    let equitySeries: number[] = [];
    if (selectedStrategy === "all") {
      equitySeries = combined;
    } else if (selectedStrategy === "swing") {
      equitySeries = swing;
    } else if (selectedStrategy === "intraday") {
      equitySeries = intraday;
    }

    if (equitySeries.length === 0) return [];

    // Calculate cutoff date based on time range
    const now = new Date();
    let cutoffDate = new Date(0);
    
    if (timeRange === '1M') {
      cutoffDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
    } else if (timeRange === '3M') {
      cutoffDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
    } else if (timeRange === '6M') {
      cutoffDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
    } else if (timeRange === '1Y') {
      cutoffDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
    }

    // Build underwater chart data (drawdown from peak)
    // Start with first non-zero equity value to avoid division by zero
    let peak = Math.max(equitySeries[0], 1); // Ensure peak is at least 1
    const result = [];

    for (let i = 0; i < dates.length; i++) {
      const date = new Date(dates[i]);
      if (date < cutoffDate) continue;

      const equity = equitySeries[i];
      
      // Update peak
      if (equity > peak) peak = equity;

      // Calculate drawdown
      const drawdown = equity - peak;
      const drawdownPercent = peak > 0 ? (drawdown / peak) * 100 : 0;

      result.push({
        date: date.toISOString().split('T')[0],
        drawdown,
        drawdownPercent,
        equity,
        peak,
      });
    }

    return result;
  }, [equityCurveData, selectedStrategy, timeRange]);

  // Calculate drawdown statistics
  const drawdownStats = useMemo(() => {
    if (drawdownData.length === 0) return null;

    const maxDrawdown = Math.min(...drawdownData.map(d => d.drawdown));
    const maxDrawdownPercent = Math.min(...drawdownData.map(d => d.drawdownPercent));
    const currentDrawdown = drawdownData[drawdownData.length - 1]?.drawdown || 0;
    const currentDrawdownPercent = drawdownData[drawdownData.length - 1]?.drawdownPercent || 0;

    // Find longest drawdown period
    let currentPeriodStart = -1;
    let longestPeriod = 0;
    let currentPeriod = 0;

    drawdownData.forEach((point, idx) => {
      if (point.drawdown < 0) {
        if (currentPeriodStart === -1) currentPeriodStart = idx;
        currentPeriod = idx - currentPeriodStart + 1;
        if (currentPeriod > longestPeriod) longestPeriod = currentPeriod;
      } else {
        currentPeriodStart = -1;
        currentPeriod = 0;
      }
    });

    // Calculate average drawdown (only negative values)
    const negativeDrawdowns = drawdownData.filter(d => d.drawdown < 0);
    const avgDrawdown = negativeDrawdowns.length > 0
      ? negativeDrawdowns.reduce((sum, d) => sum + d.drawdown, 0) / negativeDrawdowns.length
      : 0;

    return {
      maxDrawdown,
      maxDrawdownPercent,
      currentDrawdown,
      currentDrawdownPercent,
      longestPeriod,
      avgDrawdown,
    };
  }, [drawdownData]);

  // Group drawdowns into buckets for histogram
  const drawdownHistogram = useMemo(() => {
    if (drawdownData.length === 0) return [];

    const buckets = [
      { range: '0%', min: 0, max: 0, count: 0 },
      { range: '0-2%', min: -2, max: 0, count: 0 },
      { range: '2-5%', min: -5, max: -2, count: 0 },
      { range: '5-10%', min: -10, max: -5, count: 0 },
      { range: '10-20%', min: -20, max: -10, count: 0 },
      { range: '>20%', min: -100, max: -20, count: 0 },
    ];

    drawdownData.forEach(point => {
      const dd = point.drawdownPercent;
      for (const bucket of buckets) {
        if (dd > bucket.min && dd <= bucket.max) {
          bucket.count++;
          break;
        }
      }
    });

    return buckets;
  }, [drawdownData]);

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white">Drawdown Analysis</h1>
        <p className="text-slate-400 mt-1">Underwater chart and drawdown statistics</p>
      </div>

      <div className="space-y-6">
        {/* Controls */}
        <div className="flex gap-4 items-center">
          <Select value={selectedStrategy} onValueChange={setSelectedStrategy}>
            <SelectTrigger className="w-[200px] bg-slate-800 border-slate-700">
              <SelectValue placeholder="Select strategy" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Strategies</SelectItem>
              <SelectItem value="swing">Swing Only</SelectItem>
              <SelectItem value="intraday">Intraday Only</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-2">
            {(['1M', '3M', '6M', '1Y', 'ALL'] as TimeRange[]).map(range => (
              <Button
                key={range}
                variant={timeRange === range ? 'default' : 'outline'}
                size="sm"
                onClick={() => setTimeRange(range)}
                className="min-w-[60px]"
              >
                {range}
              </Button>
            ))}
          </div>
        </div>

        {/* Drawdown Statistics Cards */}
        {drawdownStats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  Max Drawdown
                </CardTitle>
                <TrendingDown className="h-4 w-4 text-red-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-400">
                  ${drawdownStats.maxDrawdown.toFixed(0)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {drawdownStats.maxDrawdownPercent.toFixed(2)}% from peak
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  Current Drawdown
                </CardTitle>
                <AlertTriangle className="h-4 w-4 text-amber-400" />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${
                  drawdownStats.currentDrawdown < 0 ? 'text-red-400' : 'text-green-400'
                }`}>
                  ${drawdownStats.currentDrawdown.toFixed(0)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {drawdownStats.currentDrawdownPercent.toFixed(2)}% from peak
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  Longest Period
                </CardTitle>
                <Clock className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {drawdownStats.longestPeriod}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  days in drawdown
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  Avg Drawdown
                </CardTitle>
                <Target className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-slate-300">
                  ${drawdownStats.avgDrawdown.toFixed(0)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  average negative DD
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Underwater Chart */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Underwater Chart</CardTitle>
            <p className="text-sm text-slate-400">Drawdown from peak equity</p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                Loading drawdown data...
              </div>
            ) : drawdownData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={drawdownData}>
                  <defs>
                    <linearGradient id="colorDrawdown" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="date"
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    tickFormatter={(value) => `${value.toFixed(0)}%`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#f8fafc' }}
                    formatter={(value: any) => [`${value.toFixed(2)}%`, 'Drawdown']}
                  />
                  <ReferenceLine y={0} stroke="#64748b" strokeDasharray="3 3" />
                  <Area
                    type="monotone"
                    dataKey="drawdownPercent"
                    stroke="#ef4444"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorDrawdown)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Drawdown Distribution Histogram */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Drawdown Distribution</CardTitle>
            <p className="text-sm text-slate-400">Frequency of drawdown levels</p>
          </CardHeader>
          <CardContent>
            {drawdownHistogram.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={drawdownHistogram}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="range"
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <YAxis
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'Days', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
