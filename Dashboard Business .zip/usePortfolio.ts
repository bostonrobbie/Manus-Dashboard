import { useEffect, useState } from 'react';
import { portfolio, type PortfolioOverview, type EquityCurveResponse, type AnalyticsResponse, type PositionsResponse } from '@/lib/api';

/**
 * Hook to fetch portfolio overview
 */
export function usePortfolioOverview() {
  const [data, setData] = useState<PortfolioOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await portfolio.getOverview();
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, []);

  return { data, loading, error, refetch };
}

/**
 * Hook to fetch equity curve
 */
export function useEquityCurve(params?: {
  start_date?: string;
  end_date?: string;
  limit?: number;
}) {
  const [data, setData] = useState<EquityCurveResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await portfolio.getEquityCurve(params);
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, [params?.start_date, params?.end_date, params?.limit]);

  return { data, loading, error, refetch };
}

/**
 * Hook to fetch analytics time series
 */
export function useAnalytics(params?: {
  start_date?: string;
  end_date?: string;
  limit?: number;
}) {
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await portfolio.getAnalytics(params);
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, [params?.start_date, params?.end_date, params?.limit]);

  return { data, loading, error, refetch };
}

/**
 * Hook to fetch current positions
 */
export function usePositions(activeOnly: boolean = true) {
  const [data, setData] = useState<PositionsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refetch = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await portfolio.getPositions(activeOnly);
      setData(result);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refetch();
  }, [activeOnly]);

  return { data, loading, error, refetch };
}
