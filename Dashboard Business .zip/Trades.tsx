import { TradesTable } from "@/components/TradesTable";
import { MetricCard } from "@/components/MetricCard";
import { useTradeStats } from "@/hooks/useTrades";
import { Target, TrendingUp, TrendingDown, DollarSign, BarChart3, ListFilter } from "lucide-react";
import { Link } from "wouter";

export default function Trades() {
  const { data: stats, loading } = useTradeStats();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-6">
            <h1 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
              Trading Dashboard
            </h1>
            <nav className="flex items-center gap-4">
              <Link href="/">
                <a className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                  <BarChart3 className="h-4 w-4" />
                  Dashboard
                </a>
              </Link>
              <Link href="/trades">
                <a className="flex items-center gap-2 text-sm text-foreground font-medium">
                  <ListFilter className="h-4 w-4" />
                  Trades
                </a>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="container py-8 space-y-8">
        {/* Trade Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total PnL"
            value={stats?.total_pnl || 0}
            format="currency"
            icon={<DollarSign className="h-5 w-5" />}
            loading={loading}
          />
          <MetricCard
            title="Win Rate"
            value={stats?.win_rate ? (stats.win_rate * 100).toFixed(1) : 'N/A'}
            format="percent"
            icon={<Target className="h-5 w-5" />}
            loading={loading}
          />
          <MetricCard
            title="Avg Win"
            value={stats?.avg_win || 0}
            format="currency"
            icon={<TrendingUp className="h-5 w-5" />}
            loading={loading}
          />
          <MetricCard
            title="Avg Loss"
            value={stats?.avg_loss || 0}
            format="currency"
            icon={<TrendingDown className="h-5 w-5" />}
            loading={loading}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Profit Factor"
            value={stats?.profit_factor?.toFixed(2) || 'N/A'}
            loading={loading}
          />
          <MetricCard
            title="Expectancy"
            value={stats?.expectancy || 0}
            format="currency"
            loading={loading}
          />
          <MetricCard
            title="Largest Win"
            value={stats?.largest_win || 0}
            format="currency"
            loading={loading}
          />
          <MetricCard
            title="Largest Loss"
            value={stats?.largest_loss || 0}
            format="currency"
            loading={loading}
          />
        </div>

        {/* Trades Table */}
        <TradesTable />
      </main>
    </div>
  );
}
