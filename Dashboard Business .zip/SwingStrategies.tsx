import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Activity, DollarSign, Target, Clock } from "lucide-react";
import { Link } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { ContractSizeToggle, useContractSize, scaleByContractSize } from "@/components/ContractSizeToggle";

export default function SwingStrategies() {
  const contractSize = useContractSize();
  const [selectedStrategy, setSelectedStrategy] = useState<number | "all">("all");
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "90d" | "1y" | "all">("30d");

  // Fetch strategies
  const { data: strategies = [] } = trpc.strategies.list.useQuery();
  
  // Filter for swing strategies
  const swingStrategies = strategies.filter(s => s.type === 'swing');

  // Fetch portfolio data (overview doesn't take parameters - it's user-scoped)
  const { data: overview } = trpc.portfolio.overview.useQuery();

  const { data: equityCurve = [] } = trpc.portfolio.equityCurve.useQuery({
    strategyId: selectedStrategy === "all" ? undefined : selectedStrategy
  });

  const { data: trades = [] } = trpc.trades.list.useQuery({
    strategyId: selectedStrategy === "all" ? undefined : selectedStrategy,
    limit: 100
  });

  const { data: tradeStats } = trpc.trades.statistics.useQuery({
    strategyId: selectedStrategy === "all" ? undefined : selectedStrategy
  });

  // Calculate additional metrics
  const winningTrades = trades.filter(t => t.pnl && t.pnl > 0);
  const losingTrades = trades.filter(t => t.pnl && t.pnl < 0);
  const avgWin = winningTrades.length > 0 
    ? winningTrades.reduce((sum, t) => sum + (t.pnl || 0), 0) / winningTrades.length 
    : 0;
  const avgLoss = losingTrades.length > 0 
    ? losingTrades.reduce((sum, t) => sum + (t.pnl || 0), 0) / losingTrades.length 
    : 0;
  const profitFactor = avgLoss !== 0 ? Math.abs(avgWin / avgLoss) : 0;
  const largestWin = winningTrades.length > 0 ? Math.max(...winningTrades.map(t => t.pnl || 0)) : 0;
  const largestLoss = losingTrades.length > 0 ? Math.min(...losingTrades.map(t => t.pnl || 0)) : 0;

  // Calculate average hold time (in days)
  const tradesWithDuration = trades.filter(t => t.entryTime && t.exitTime);
  const avgHoldTime = tradesWithDuration.length > 0
    ? tradesWithDuration.reduce((sum, t) => {
        const duration = new Date(t.exitTime!).getTime() - new Date(t.entryTime).getTime();
        return sum + duration;
      }, 0) / tradesWithDuration.length / (1000 * 60 * 60 * 24) // Convert to days
    : 0;

  // Normalize equity curve to start at $0 and scale by contract size
  const normalizedEquityCurve = equityCurve.length > 0
    ? equityCurve.map(point => ({
        ...point,
        equity: scaleByContractSize(point.equity - equityCurve[0].equity, contractSize),
      }))
    : [];

  // Scale metrics by contract size
  const scaledAvgWin = scaleByContractSize(avgWin, contractSize);
  const scaledAvgLoss = scaleByContractSize(avgLoss, contractSize);
  const scaledLargestWin = scaleByContractSize(largestWin, contractSize);
  const scaledLargestLoss = scaleByContractSize(largestLoss, contractSize);

  // Prepare daily returns data for bar chart
  const dailyReturns = equityCurve.map((point, index) => {
    if (index === 0) return { date: point.date, return: 0 };
    const prevEquity = equityCurve[index - 1].equity;
    const returnPct = prevEquity !== 0 ? ((point.equity - prevEquity) / prevEquity) * 100 : 0;
    // Filter out invalid values
    const validReturn = isFinite(returnPct) ? returnPct : 0;
    return {
      date: point.date,
      return: validReturn
    };
  }).slice(1);

  // Calculate win rate trend (rolling 20-trade window)
  const winRateTrend = trades
    .slice(0, 100)
    .reverse()
    .map((trade, index, arr) => {
      const window = arr.slice(Math.max(0, index - 19), index + 1);
      const wins = window.filter(t => t.pnl && t.pnl > 0).length;
      const winRate = (wins / window.length) * 100;
      return {
        tradeNumber: index + 1,
        winRate: winRate,
        date: trade.exitTime || trade.entryTime
      };
    })
    .filter((_, i) => i >= 19); // Only show after we have 20 trades

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            Swing Strategies
          </h1>
          <p className="text-slate-400 mt-1">Deep historical analysis and performance metrics</p>
        </div>

        <div className="flex gap-4 items-center">
          <ContractSizeToggle />
          
          <Select value={String(selectedStrategy)} onValueChange={(v) => setSelectedStrategy(v === "all" ? "all" : Number(v))}>
            <SelectTrigger className="w-[200px] bg-slate-800/50 border-slate-700">
              <SelectValue placeholder="Select strategy" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Swing Strategies</SelectItem>
              {swingStrategies.map(s => (
                <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={timeRange} onValueChange={(v: any) => setTimeRange(v)}>
            <SelectTrigger className="w-[150px] bg-slate-800/50 border-slate-700">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
              <SelectItem value="all">All time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Key Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Total Return</span>
              <TrendingUp className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {overview ? `${overview.totalReturn >= 0 ? '+' : ''}${overview.totalReturn.toFixed(2)}%` : '0%'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Win Rate</span>
              <Target className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {tradeStats ? `${tradeStats.winRate.toFixed(1)}%` : '0%'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Profit Factor</span>
              <Activity className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {profitFactor > 0 ? profitFactor.toFixed(2) : 'N/A'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Avg Hold Time</span>
              <Clock className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-slate-100">
              {avgHoldTime > 0 ? `${avgHoldTime.toFixed(1)}d` : 'N/A'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Best Trade</span>
              <TrendingUp className="w-4 h-4 text-green-400" />
            </div>
            <div className="text-2xl font-bold text-green-400">
              {scaledLargestWin > 0 ? `$${scaledLargestWin.toFixed(0)}` : '$0'}
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-slate-700/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-400">Worst Trade</span>
              <TrendingDown className="w-4 h-4 text-red-400" />
            </div>
            <div className="text-2xl font-bold text-red-400">
              {scaledLargestLoss < 0 ? `$${scaledLargestLoss.toFixed(0)}` : '$0'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1: Equity Curve + Daily Returns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Equity Curve */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Equity Curve</CardTitle>
          </CardHeader>
          <CardContent>
            {normalizedEquityCurve.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={normalizedEquityCurve}>
                  <defs>
                    <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="equity" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    fill="url(#equityGradient)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No equity data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Daily Returns */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Daily Returns</CardTitle>
          </CardHeader>
          <CardContent>
            {dailyReturns.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dailyReturns}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    tickFormatter={(value) => typeof value === 'number' && isFinite(value) ? `${value.toFixed(1)}%` : '0%'}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Bar 
                    dataKey="return" 
                    fill="#3b82f6"
                    radius={[4, 4, 0, 0]}
                  >
                    {dailyReturns.map((entry, index) => (
                      <rect key={index} fill={entry.return >= 0 ? '#10b981' : '#ef4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No returns data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2: Win Rate Trend + Trade Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Win Rate Trend */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Win Rate Trend (Rolling 20 Trades)</CardTitle>
          </CardHeader>
          <CardContent>
            {winRateTrend.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={winRateTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="tradeNumber" 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    label={{ value: 'Trade Number', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                  />
                  <YAxis 
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    domain={[0, 100]}
                    label={{ value: 'Win Rate (%)', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                    labelStyle={{ color: '#f8fafc' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="winRate" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                Need at least 20 trades to show trend
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trade Distribution */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Trade P&L Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {trades.length > 0 ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Winning Trades</span>
                  <span className="text-green-400 font-bold">{winningTrades.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Losing Trades</span>
                  <span className="text-red-400 font-bold">{losingTrades.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Average Win</span>
                  <span className="text-green-400 font-bold">${scaledAvgWin.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Average Loss</span>
                  <span className="text-red-400 font-bold">${scaledAvgLoss.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-slate-700">
                  <span className="text-slate-300 font-semibold">Profit Factor</span>
                  <span className={`font-bold ${profitFactor > 1.5 ? 'text-green-400' : profitFactor > 1 ? 'text-yellow-400' : 'text-red-400'}`}>
                    {profitFactor.toFixed(2)}
                  </span>
                </div>
                <div className="text-xs text-slate-500 mt-2">
                  {profitFactor > 1.5 ? '✓ Excellent profit factor' : profitFactor > 1 ? '⚠ Acceptable profit factor' : '✗ Poor profit factor'}
                </div>
              </div>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-slate-400">
                No trade data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Trades Table */}
      <Card className="glass-card border-slate-700/50">
        <CardHeader>
          <CardTitle className="text-slate-100">Recent Trades</CardTitle>
        </CardHeader>
        <CardContent>
          {trades.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-700">
                    <th className="text-left p-3 text-slate-400 font-medium">Date</th>
                    <th className="text-left p-3 text-slate-400 font-medium">Symbol</th>
                    <th className="text-left p-3 text-slate-400 font-medium">Side</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Entry</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Exit</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Qty</th>
                    <th className="text-right p-3 text-slate-400 font-medium">P&L</th>
                    <th className="text-right p-3 text-slate-400 font-medium">Return</th>
                  </tr>
                </thead>
                <tbody>
                  {trades.slice(0, 20).map((trade) => (
                    <tr key={trade.id} className="border-b border-slate-800 hover:bg-slate-800/30">
                      <td className="p-3 text-slate-300">
                        {new Date(trade.entryTime).toLocaleDateString()}
                      </td>
                      <td className="p-3 text-slate-100 font-medium">{trade.symbol}</td>
                      <td className="p-3">
                        <span className={`px-2 py-1 rounded text-xs ${
                          trade.side === 'long' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {trade.side.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-3 text-right text-slate-300">${trade.entryPrice.toFixed(2)}</td>
                      <td className="p-3 text-right text-slate-300">
                        {trade.exitPrice ? `$${trade.exitPrice.toFixed(2)}` : '-'}
                      </td>
                      <td className="p-3 text-right text-slate-300">{trade.quantity}</td>
                      <td className={`p-3 text-right font-medium ${
                        trade.pnl && trade.pnl > 0 ? 'text-green-400' : trade.pnl && trade.pnl < 0 ? 'text-red-400' : 'text-slate-400'
                      }`}>
                        {trade.pnl ? `$${trade.pnl.toFixed(2)}` : '-'}
                      </td>
                      <td className={`p-3 text-right font-medium ${
                        trade.pnlPercent && trade.pnlPercent > 0 ? 'text-green-400' : trade.pnlPercent && trade.pnlPercent < 0 ? 'text-red-400' : 'text-slate-400'
                      }`}>
                        {trade.pnlPercent ? `${trade.pnlPercent >= 0 ? '+' : ''}${trade.pnlPercent.toFixed(2)}%` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              No trades yet. Start sending webhooks from TradingView!
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
