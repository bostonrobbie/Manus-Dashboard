import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Legend } from "recharts";
import { TrendingUp, Target, Activity } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";

export default function RollingMetrics() {
  const [selectedStrategy, setSelectedStrategy] = useState<string>("all");

  // Fetch all strategies
  const { data: strategies = [] } = trpc.strategies.list.useQuery();

  // Fetch trades for selected strategy
  const { data: trades = [], isLoading } = trpc.trades.list.useQuery({});

  // Calculate rolling metrics
  const rollingData = useMemo(() => {
    if (trades.length === 0) return { sharpe: [], winRate: [] };

    // Filter trades by strategy
    let filteredTrades = trades;
    if (selectedStrategy !== "all") {
      const strategyId = parseInt(selectedStrategy);
      filteredTrades = trades.filter(t => t.strategyId === strategyId);
    }

    // Sort trades by exit date
    const sortedTrades = [...filteredTrades]
      .filter(t => t.exitTime)
      .sort((a, b) => new Date(a.exitTime!).getTime() - new Date(b.exitTime!).getTime());

    if (sortedTrades.length === 0) return { sharpe: [], winRate: [] };

    // Calculate rolling metrics for each window
    const windows = [30, 60, 90];
    const sharpeData: any[] = [];
    const winRateData: any[] = [];

    // Group trades by date
    const tradesByDate = new Map<string, typeof sortedTrades>();
    sortedTrades.forEach(trade => {
      const dateKey = new Date(trade.exitTime!).toISOString().split('T')[0];
      if (!tradesByDate.has(dateKey)) {
        tradesByDate.set(dateKey, []);
      }
      tradesByDate.get(dateKey)!.push(trade);
    });

    const dates = Array.from(tradesByDate.keys()).sort();

    // Calculate rolling metrics for each date
    dates.forEach((date, idx) => {
      const currentDate = new Date(date);

      const sharpePoint: any = { date };
      const winRatePoint: any = { date };

      windows.forEach(window => {
        const startDate = new Date(currentDate);
        startDate.setDate(startDate.getDate() - window);

        // Get trades in window
        const windowTrades = sortedTrades.filter(t => {
          const exitTime = new Date(t.exitTime!);
          return exitTime >= startDate && exitTime <= currentDate;
        });

        if (windowTrades.length >= 5) { // Minimum trades for meaningful metrics
          // Calculate Sharpe ratio
          const returns = windowTrades.map(t => t.pnl || 0);
          const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
          const variance = returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
          const stdDev = Math.sqrt(variance);
          const sharpe = stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0; // Annualized

          sharpePoint[`sharpe${window}`] = sharpe;

          // Calculate win rate
          const winningTrades = windowTrades.filter(t => (t.pnl || 0) > 0).length;
          const winRate = (winningTrades / windowTrades.length) * 100;

          winRatePoint[`winRate${window}`] = winRate;
        }
      });

      // Only add if we have at least one metric
      if (Object.keys(sharpePoint).length > 1) {
        sharpeData.push(sharpePoint);
        winRateData.push(winRatePoint);
      }
    });

    return { sharpe: sharpeData, winRate: winRateData };
  }, [trades, selectedStrategy]);

  // Calculate current metrics
  const currentMetrics = useMemo(() => {
    if (rollingData.sharpe.length === 0) return null;

    const latest = rollingData.sharpe[rollingData.sharpe.length - 1];
    const latestWinRate = rollingData.winRate[rollingData.winRate.length - 1];

    return {
      sharpe30: latest.sharpe30 || 0,
      sharpe60: latest.sharpe60 || 0,
      sharpe90: latest.sharpe90 || 0,
      winRate30: latestWinRate.winRate30 || 0,
      winRate60: latestWinRate.winRate60 || 0,
      winRate90: latestWinRate.winRate90 || 0,
    };
  }, [rollingData]);

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white">Rolling Metrics</h1>
        <p className="text-slate-400 mt-1">30/60/90-day rolling performance indicators</p>
      </div>

      <div className="space-y-6">
        {/* Strategy Selector */}
        <div className="flex gap-4 items-center">
          <Select value={selectedStrategy} onValueChange={setSelectedStrategy}>
            <SelectTrigger className="w-[250px] bg-slate-800 border-slate-700">
              <SelectValue placeholder="Select strategy" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Strategies</SelectItem>
              {strategies.map(s => (
                <SelectItem key={s.id} value={s.id.toString()}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Current Metrics Cards */}
        {currentMetrics && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  30-Day Sharpe
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-blue-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {currentMetrics.sharpe30.toFixed(2)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Rolling 30-day annualized
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  60-Day Sharpe
                </CardTitle>
                <Activity className="h-4 w-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {currentMetrics.sharpe60.toFixed(2)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Rolling 60-day annualized
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-slate-700/50">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-slate-300">
                  90-Day Sharpe
                </CardTitle>
                <Target className="h-4 w-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">
                  {currentMetrics.sharpe90.toFixed(2)}
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Rolling 90-day annualized
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Rolling Sharpe Ratio Chart */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Rolling Sharpe Ratio</CardTitle>
            <p className="text-sm text-slate-400">30/60/90-day rolling annualized Sharpe ratio</p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                Loading metrics...
              </div>
            ) : rollingData.sharpe.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={rollingData.sharpe}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="date"
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#f8fafc' }}
                    formatter={(value: any) => value.toFixed(2)}
                  />
                  <Legend />
                  <ReferenceLine y={0} stroke="#64748b" strokeDasharray="3 3" />
                  <Line
                    type="monotone"
                    dataKey="sharpe30"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    dot={false}
                    name="30-Day"
                  />
                  <Line
                    type="monotone"
                    dataKey="sharpe60"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={false}
                    name="60-Day"
                  />
                  <Line
                    type="monotone"
                    dataKey="sharpe90"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    dot={false}
                    name="90-Day"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                No data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rolling Win Rate Chart */}
        <Card className="glass-card border-slate-700/50">
          <CardHeader>
            <CardTitle className="text-slate-100">Rolling Win Rate</CardTitle>
            <p className="text-sm text-slate-400">30/60/90-day rolling win rate percentage</p>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                Loading metrics...
              </div>
            ) : rollingData.winRate.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={rollingData.winRate}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis
                    dataKey="date"
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString()}
                  />
                  <YAxis
                    stroke="#64748b"
                    tick={{ fill: '#94a3b8' }}
                    domain={[0, 100]}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: '#f8fafc' }}
                    formatter={(value: any) => `${value.toFixed(1)}%`}
                  />
                  <Legend />
                  <ReferenceLine y={50} stroke="#64748b" strokeDasharray="3 3" />
                  <Line
                    type="monotone"
                    dataKey="winRate30"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    dot={false}
                    name="30-Day"
                  />
                  <Line
                    type="monotone"
                    dataKey="winRate60"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={false}
                    name="60-Day"
                  />
                  <Line
                    type="monotone"
                    dataKey="winRate90"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    dot={false}
                    name="90-Day"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-slate-400">
                No data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
