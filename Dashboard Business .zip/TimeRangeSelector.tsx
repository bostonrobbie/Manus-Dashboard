import * as React from "react";
import { Button } from "@/components/ui/button";

export type TimeRangeValue = "1M" | "3M" | "6M" | "1Y" | "YTD" | "ALL";

interface TimeRangeSelectorProps {
  value: TimeRangeValue;
  onChange: (
    range: TimeRangeValue,
    startDate?: string,
    endDate?: string
  ) => void;
}

export function TimeRangeSelector({
  value,
  onChange,
}: TimeRangeSelectorProps) {
  const ranges: TimeRangeValue[] = ["1M", "3M", "6M", "1Y", "YTD", "ALL"];

  const handleClick = (range: TimeRangeValue) => {
    const { startDate, endDate } = computeDates(range);
    onChange(range, startDate, endDate);
  };

  return (
    <div className="inline-flex flex-wrap gap-2">
      {ranges.map((range) => (
        <Button
          key={range}
          variant={range === value ? "default" : "outline"}
          size="sm"
          onClick={() => handleClick(range)}
        >
          {range}
        </Button>
      ))}
    </div>
  );
}

function computeDates(range: TimeRangeValue): {
  startDate?: string;
  endDate?: string;
} {
  const now = new Date();
  const endDate = toIsoDate(now);

  const clone = (d: Date) => new Date(d.getTime());

  if (range === "ALL") {
    return {};
  }

  if (range === "YTD") {
    const start = new Date(now.getFullYear(), 0, 1);
    return { startDate: toIsoDate(start), endDate };
  }

  let daysBack = 0;
  if (range === "1M") daysBack = 30;
  if (range === "3M") daysBack = 90;
  if (range === "6M") daysBack = 180;
  if (range === "1Y") daysBack = 365;

  const start = clone(now);
  start.setDate(start.getDate() - daysBack);

  return { startDate: toIsoDate(start), endDate };
}

function toIsoDate(d: Date): string {
  const year = d.getFullYear();
  const month = d.getMonth() + 1;
  const day = d.getDate();
  const mm = month < 10 ? `0${month}` : String(month);
  const dd = day < 10 ? `0${day}` : String(day);
  return `${year}-${mm}-${dd}`;
}
