export function ChartSkeleton({ height = 300 }: { height?: number }) {
  return (
    <div className="animate-pulse" style={{ height: `${height}px` }}>
      <div className="h-full bg-slate-800/50 rounded-lg flex items-end justify-between px-8 pb-8 gap-2">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="bg-slate-700/50 rounded-t"
            style={{
              height: `${Math.random() * 80 + 20}%`,
              width: '100%',
            }}
          />
        ))}
      </div>
    </div>
  );
}

export function MetricCardSkeleton() {
  return (
    <div className="glass-card p-6 animate-pulse">
      <div className="flex items-center justify-between mb-2">
        <div className="h-4 w-24 bg-slate-700 rounded"></div>
        <div className="h-4 w-4 bg-slate-700 rounded"></div>
      </div>
      <div className="h-8 w-32 bg-slate-700 rounded mb-2"></div>
      <div className="h-3 w-20 bg-slate-700 rounded"></div>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="animate-pulse space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-4">
          <div className="h-4 bg-slate-700 rounded flex-1"></div>
          <div className="h-4 bg-slate-700 rounded w-24"></div>
          <div className="h-4 bg-slate-700 rounded w-24"></div>
          <div className="h-4 bg-slate-700 rounded w-32"></div>
        </div>
      ))}
    </div>
  );
}
