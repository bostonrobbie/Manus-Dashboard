import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Scale } from 'lucide-react';

export type ContractSize = 'mini' | 'micro';

interface ContractSizeToggleProps {
  onChange?: (size: ContractSize) => void;
  className?: string;
}

/**
 * Toggle between mini and micro contract views
 * 
 * Mini: Full size contracts with $100k initial capital
 * Micro: 1/4 size contracts with $25k initial capital (scales all values by 0.25x)
 */
export function ContractSizeToggle({ onChange, className }: ContractSizeToggleProps) {
  const [contractSize, setContractSize] = useState<ContractSize>('mini');

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('contractSize') as ContractSize;
    if (saved === 'mini' || saved === 'micro') {
      setContractSize(saved);
      onChange?.(saved);
    }
  }, [onChange]);

  const handleToggle = () => {
    const newSize: ContractSize = contractSize === 'mini' ? 'micro' : 'mini';
    setContractSize(newSize);
    localStorage.setItem('contractSize', newSize);
    onChange?.(newSize);
  };

  return (
    <div className={`flex items-center gap-2 ${className || ''}`}>
      <span className="text-sm text-muted-foreground">Contract Size:</span>
      <Button
        variant={contractSize === 'mini' ? 'default' : 'outline'}
        size="sm"
        onClick={handleToggle}
        className="gap-2"
      >
        <Scale className="h-4 w-4" />
        {contractSize === 'mini' ? 'Mini ($100k)' : 'Micro ($25k)'}
      </Button>
      <span className="text-xs text-muted-foreground">
        {contractSize === 'micro' && '(All values scaled to 0.25x)'}
      </span>
    </div>
  );
}

/**
 * Hook to get current contract size from localStorage
 */
export function useContractSize(): ContractSize {
  const [contractSize, setContractSize] = useState<ContractSize>('mini');

  useEffect(() => {
    const saved = localStorage.getItem('contractSize') as ContractSize;
    if (saved === 'mini' || saved === 'micro') {
      setContractSize(saved);
    }

    // Listen for storage changes
    const handleStorageChange = () => {
      const updated = localStorage.getItem('contractSize') as ContractSize;
      if (updated === 'mini' || updated === 'micro') {
        setContractSize(updated);
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Also listen for custom event for same-tab updates
    const handleCustomEvent = (e: Event) => {
      const customEvent = e as CustomEvent<ContractSize>;
      setContractSize(customEvent.detail);
    };
    
    window.addEventListener('contractSizeChange', handleCustomEvent);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('contractSizeChange', handleCustomEvent);
    };
  }, []);

  return contractSize;
}

/**
 * Scale a value based on contract size
 * Micro contracts are 1/4 the size of mini contracts
 */
export function scaleByContractSize(value: number, contractSize: ContractSize): number {
  return contractSize === 'micro' ? value * 0.25 : value;
}
