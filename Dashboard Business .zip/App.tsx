import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardNew from "./pages/DashboardNew";
import SwingStrategies from "./pages/SwingStrategies";
import IntradayStrategies from "./pages/IntradayStrategies";
import LiveAlerts from "./pages/LiveAlerts";
import Trades from "./pages/Trades";
import CompareStrategies from "./pages/CompareStrategies";
import DrawdownAnalysis from "./pages/DrawdownAnalysis";
import RollingMetrics from "./pages/RollingMetrics";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
     <Switch>
      <Route path={"/"} component={DashboardNew} />
      <Route path={"/swing"} component={SwingStrategies} />
      <Route path={"/intraday"} component={IntradayStrategies} />
      <Route path={"/alerts"} component={LiveAlerts} />
      <Route path={"/compare"} component={CompareStrategies} />
      <Route path="/drawdown" component={DrawdownAnalysis} />
      <Route path="/rolling-metrics" component={RollingMetrics} />
      <Route path={"/trades"} component={Trades} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
