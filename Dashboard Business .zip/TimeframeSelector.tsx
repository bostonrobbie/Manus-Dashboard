import { Button } from "@/components/ui/button";

export type Timeframe = "1D" | "1W" | "1M" | "3M" | "6M" | "1Y" | "YTD" | "ALL";

interface TimeframeSelectorProps {
  selected: Timeframe;
  onChange: (timeframe: Timeframe) => void;
  className?: string;
}

const timeframes: Timeframe[] = ["1D", "1W", "1M", "3M", "6M", "1Y", "YTD", "ALL"];

export function TimeframeSelector({ selected, onChange, className = "" }: TimeframeSelectorProps) {
  return (
    <div className={`flex gap-1 flex-wrap ${className}`}>
      {timeframes.map((tf) => (
        <Button
          key={tf}
          variant={selected === tf ? "default" : "outline"}
          size="sm"
          onClick={() => onChange(tf)}
          className="min-w-[50px]"
        >
          {tf}
        </Button>
      ))}
    </div>
  );
}

// Helper function to calculate date range from timeframe
export function getDateRangeFromTimeframe(timeframe: Timeframe): { startDate: Date; endDate: Date } {
  const endDate = new Date();
  const startDate = new Date();

  switch (timeframe) {
    case "1D":
      startDate.setDate(endDate.getDate() - 1);
      break;
    case "1W":
      startDate.setDate(endDate.getDate() - 7);
      break;
    case "1M":
      startDate.setMonth(endDate.getMonth() - 1);
      break;
    case "3M":
      startDate.setMonth(endDate.getMonth() - 3);
      break;
    case "6M":
      startDate.setMonth(endDate.getMonth() - 6);
      break;
    case "1Y":
      startDate.setFullYear(endDate.getFullYear() - 1);
      break;
    case "YTD":
      startDate.setMonth(0, 1); // January 1st of current year
      break;
    case "ALL":
      startDate.setFullYear(1990); // Far enough back to get all data
      break;
  }

  return { startDate, endDate };
}
