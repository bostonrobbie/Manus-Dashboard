import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";

const COLORS = [
  '#3b82f6', // blue
  '#10b981', // green
  '#f59e0b', // amber
  '#ef4444', // red
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#14b8a6', // teal
  '#f97316', // orange
  '#6366f1', // indigo
  '#84cc16', // lime
];

type TimeRange = '1M' | '3M' | '6M' | '1Y' | 'ALL';

export default function CompareStrategies() {
  const [selectedStrategyIds, setSelectedStrategyIds] = useState<number[]>([]);
  const [timeRange, setTimeRange] = useState<TimeRange>('ALL');

  // Fetch all strategies
  const { data: strategies = [] } = trpc.strategies.list.useQuery();

  // Fetch comparison data for selected strategies
  const { data: comparisonData, isLoading } = trpc.portfolio.compareStrategies.useQuery(
    {
      strategyIds: selectedStrategyIds,
    },
    {
      enabled: selectedStrategyIds.length > 0,
    }
  );

  // Toggle strategy selection
  const toggleStrategy = (strategyId: number) => {
    setSelectedStrategyIds(prev =>
      prev.includes(strategyId)
        ? prev.filter(id => id !== strategyId)
        : prev.length < 10
        ? [...prev, strategyId]
        : prev
    );