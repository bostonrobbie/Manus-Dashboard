import { useEffect, useState } from "react";
import { MetricCard } from "@/components/MetricCard";
import { usePortfolioOverview, useEquityCurve, useAnalytics } from "@/hooks/usePortfolio";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  TrendingUp, 
  DollarSign, 
  Activity, 
  Target, 
  Percent,
  TrendingDown,
  Wifi,
  WifiOff,
  RefreshCw,
  BarChart3,
  ListFilter
} from "lucide-react";
import { Link } from "wouter";
import { 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { toast } from "sonner";

export default function Dashboard() {
  const { data: overview, loading: overviewLoading, refetch: refetchOverview } = usePortfolioOverview();
  const { data: equityCurve, loading: equityLoading } = useEquityCurve({ limit: 365 });
  const { data: analytics, loading: analyticsLoading } = useAnalytics({ limit: 90 });

  // WebSocket for real-time updates
  const { connected, lastMessage } = useWebSocket({
    channels: ['trades', 'equity', 'positions'],
    onMessage: (message) => {
      console.log('WebSocket message:', message);
      
      // Show toast for new trades
      if (message.channel === 'trades') {
        toast.success('New trade received', {
          description: `${message.data.side.toUpperCase()} ${message.data.qty} ${message.data.symbol} @ $${message.data.price}`,
        });
        
        // Refetch data
        refetchOverview();
      }
    },
  });

  // Format data for charts
  const equityChartData = equityCurve?.data.map(point => ({
    date: new Date(point.time).toLocaleDateString(),
    equity: point.equity,
    cash: point.cash,
  })) || [];

  const analyticsChartData = analytics?.data.map(point => ({
    date: new Date(point.date).toLocaleDateString(),
    return: point.daily_return * 100,
    cumulative: point.cumulative_return * 100,
    drawdown: point.max_drawdown * 100,
    sharpe: point.sharpe_60d,
    volatility: point.volatility_20d ? point.volatility_20d * 100 : null,
  })) || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-6">
            <h1 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
              Trading Dashboard
            </h1>
            <nav className="flex items-center gap-4">
              <Link href="/">
                <a className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                  <BarChart3 className="h-4 w-4" />
                  Dashboard
                </a>
              </Link>
              <Link href="/trades">
                <a className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                  <ListFilter className="h-4 w-4" />
                  Trades
                </a>
              </Link>
            </nav>
            <div className="flex items-center gap-2">
              {connected ? (
                <div className="flex items-center gap-2 text-success text-sm">
                  <Wifi className="h-4 w-4" />
                  <span>Live</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <WifiOff className="h-4 w-4" />
                  <span>Disconnected</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                refetchOverview();
                toast.success('Data refreshed');
              }}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-8 space-y-8">
        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Equity"
            value={overview?.equity || 0}
            format="currency"
            icon={<DollarSign className="h-5 w-5" />}
            loading={overviewLoading}
          />
          <MetricCard
            title="Daily Return"
            value={overview ? (overview.daily_return * 100).toFixed(2) : 0}
            change={overview?.daily_return ? overview.daily_return * 100 : undefined}
            format="percent"
            icon={<TrendingUp className="h-5 w-5" />}
            loading={overviewLoading}
          />
          <MetricCard
            title="Sharpe Ratio (60d)"
            value={overview?.sharpe_60d?.toFixed(2) || 'N/A'}
            icon={<Activity className="h-5 w-5" />}
            loading={overviewLoading}
          />
          <MetricCard
            title="Max Drawdown"
            value={overview ? (overview.max_drawdown * 100).toFixed(2) : 0}
            format="percent"
            icon={<TrendingDown className="h-5 w-5" />}
            loading={overviewLoading}
          />
        </div>

        {/* Secondary Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Win Rate"
            value={overview?.win_rate ? (overview.win_rate * 100).toFixed(1) : 'N/A'}
            format="percent"
            icon={<Target className="h-5 w-5" />}
            loading={overviewLoading}
          />
          <MetricCard
            title="Profit Factor"
            value={overview?.profit_factor?.toFixed(2) || 'N/A'}
            icon={<Percent className="h-5 w-5" />}
            loading={overviewLoading}
          />
          <MetricCard
            title="Active Positions"
            value={overview?.active_positions_count || 0}
            loading={overviewLoading}
          />
          <MetricCard
            title="Total Trades"
            value={overview?.total_trades_count || 0}
            loading={overviewLoading}
          />
        </div>

        {/* Equity Curve Chart */}
        <Card className="glass">
          <CardHeader>
            <CardTitle>Equity Curve</CardTitle>
          </CardHeader>
          <CardContent>
            {equityLoading ? (
              <div className="h-[400px] flex items-center justify-center">
                <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : equityChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={equityChartData}>
                  <defs>
                    <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.25 250)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="oklch(0.65 0.25 250)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                  />
                  <YAxis 
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                    tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'oklch(0.15 0.015 250)',
                      border: '1px solid oklch(0.25 0.02 250)',
                      borderRadius: '0.5rem',
                      color: 'oklch(0.95 0.005 250)'
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, 'Equity']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="equity" 
                    stroke="oklch(0.65 0.25 250)" 
                    strokeWidth={2}
                    fill="url(#equityGradient)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[400px] flex items-center justify-center text-muted-foreground">
                No equity data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Daily Returns Chart */}
        <Card className="glass">
          <CardHeader>
            <CardTitle>Daily Returns</CardTitle>
          </CardHeader>
          <CardContent>
            {analyticsLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : analyticsChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analyticsChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                  />
                  <YAxis 
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                    tickFormatter={(value) => `${value.toFixed(1)}%`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'oklch(0.15 0.015 250)',
                      border: '1px solid oklch(0.25 0.02 250)',
                      borderRadius: '0.5rem',
                      color: 'oklch(0.95 0.005 250)'
                    }}
                    formatter={(value: number) => [`${value.toFixed(2)}%`, 'Return']}
                  />
                  <Bar 
                    dataKey="return" 
                    fill="oklch(0.65 0.25 250)"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No returns data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Cumulative Returns & Drawdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="glass">
            <CardHeader>
              <CardTitle>Cumulative Returns</CardTitle>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <div className="h-[300px] flex items-center justify-center">
                  <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : analyticsChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analyticsChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" />
                    <XAxis 
                      dataKey="date" 
                      stroke="oklch(0.65 0.015 250)"
                      tick={{ fill: 'oklch(0.65 0.015 250)' }}
                    />
                    <YAxis 
                      stroke="oklch(0.65 0.015 250)"
                      tick={{ fill: 'oklch(0.65 0.015 250)' }}
                      tickFormatter={(value) => `${value.toFixed(0)}%`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'oklch(0.15 0.015 250)',
                        border: '1px solid oklch(0.25 0.02 250)',
                        borderRadius: '0.5rem',
                        color: 'oklch(0.95 0.005 250)'
                      }}
                      formatter={(value: number) => [`${value.toFixed(2)}%`, 'Cumulative Return']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="cumulative" 
                      stroke="oklch(0.65 0.2 145)" 
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  No data available
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass">
            <CardHeader>
              <CardTitle>Drawdown</CardTitle>
            </CardHeader>
            <CardContent>
              {analyticsLoading ? (
                <div className="h-[300px] flex items-center justify-center">
                  <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : analyticsChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={analyticsChartData}>
                    <defs>
                      <linearGradient id="drawdownGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="oklch(0.65 0.25 25)" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="oklch(0.65 0.25 25)" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" />
                    <XAxis 
                      dataKey="date" 
                      stroke="oklch(0.65 0.015 250)"
                      tick={{ fill: 'oklch(0.65 0.015 250)' }}
                    />
                    <YAxis 
                      stroke="oklch(0.65 0.015 250)"
                      tick={{ fill: 'oklch(0.65 0.015 250)' }}
                      tickFormatter={(value) => `${value.toFixed(0)}%`}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'oklch(0.15 0.015 250)',
                        border: '1px solid oklch(0.25 0.02 250)',
                        borderRadius: '0.5rem',
                        color: 'oklch(0.95 0.005 250)'
                      }}
                      formatter={(value: number) => [`${value.toFixed(2)}%`, 'Drawdown']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="drawdown" 
                      stroke="oklch(0.65 0.25 25)" 
                      strokeWidth={2}
                      fill="url(#drawdownGradient)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                  No data available
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Rolling Metrics */}
        <Card className="glass">
          <CardHeader>
            <CardTitle>Rolling Sharpe Ratio & Volatility</CardTitle>
          </CardHeader>
          <CardContent>
            {analyticsLoading ? (
              <div className="h-[300px] flex items-center justify-center">
                <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : analyticsChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={analyticsChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.02 250)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                  />
                  <YAxis 
                    yAxisId="left"
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                  />
                  <YAxis 
                    yAxisId="right"
                    orientation="right"
                    stroke="oklch(0.65 0.015 250)"
                    tick={{ fill: 'oklch(0.65 0.015 250)' }}
                    tickFormatter={(value) => `${value.toFixed(0)}%`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'oklch(0.15 0.015 250)',
                      border: '1px solid oklch(0.25 0.02 250)',
                      borderRadius: '0.5rem',
                      color: 'oklch(0.95 0.005 250)'
                    }}
                  />
                  <Legend />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="sharpe" 
                    stroke="oklch(0.65 0.25 250)" 
                    strokeWidth={2}
                    dot={false}
                    name="Sharpe Ratio (60d)"
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="volatility" 
                    stroke="oklch(0.65 0.2 280)" 
                    strokeWidth={2}
                    dot={false}
                    name="Volatility (20d)"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No data available
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
