import { Link, useLocation } from "wouter";
import { Home, TrendingUp, Activity, Bell, BarChart3, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Overview", icon: Home },
  { href: "/swing", label: "Swing Strategies", icon: TrendingUp },
  { href: "/intraday", label: "Intraday Strategies", icon: Activity },
  { href: "/alerts", label: "Live Alerts", icon: Bell },
];

export default function Navigation() {
  const [location] = useLocation();

  return (
    <nav className="fixed left-0 top-0 h-screen w-64 bg-slate-900/50 backdrop-blur-xl border-r border-slate-800/50 p-6 flex flex-col">
      {/* Logo */}
      <div className="mb-8">
        <Link href="/">
          <a className="flex items-center gap-3 text-xl font-bold text-white hover:text-blue-400 transition-colors">
            <BarChart3 className="w-8 h-8 text-blue-500" />
            <span>TradePulse</span>
          </a>
        </Link>
      </div>

      {/* Navigation Items */}
      <div className="flex-1 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;

          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
                  isActive
                    ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </a>
            </Link>
          );
        })}
      </div>

      {/* Footer */}
      <div className="mt-auto pt-6 border-t border-slate-800/50">
        <div className="text-xs text-slate-500 text-center">
          <p>TradePulse Dashboard</p>
          <p className="mt-1">Real-time Trading Analytics</p>
        </div>
      </div>
    </nav>
  );
}
